(function () {

  var SHADOW = (function () {
    var host = document.createElement('div');
    host.id = 'clang-mod-root';
    host.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:2147483647';
    var sh = host.attachShadow({ mode: 'open' });
    var href = './clang-mod.css';
    try { href = (document.currentScript && document.currentScript.src) ? document.currentScript.src.replace(/clang-mod\.js(\?.*)?$/, 'clang-mod.css') : './clang-mod.css'; } catch (err) { }
    var lk = document.createElement('link');
    lk.rel = 'stylesheet'; lk.href = href;
    sh.appendChild(lk);
    (document.body || document.documentElement).appendChild(host);
    return sh;
  }.call(this));
  var V = '1.0';
  var H = null, THREE = null, SCENE = null, CAM = null;
  var bootTries = 0;

  function $(tag, cls, txt) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (txt != null) e.textContent = txt;
    return e;
  }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function lerp(a, b, t) { return a + (b - a) * t; }

  function hook() {
    if (H) return H;
    var f = window.__CLANG_MOD_HOOK;
    if (typeof f !== 'function') return null;
    try {
      H = f();
      THREE = H.three;
      if (!THREE) { H = null; return null; }
    } catch (e) { H = null; return null; }
    return H;
  }
  function findScene() {
    if (SCENE && SCENE.isScene) return SCENE;
    var h = hook();
    if (!h) return null;
    var o = h.scene || h.camera || h.mapGroup && h.mapGroup.group || h.cameraWalk;
    var n = 0;
    while (o && n++ < 24) {
      if (o.isScene) { SCENE = o; break; }
      o = o.parent;
    }
    if (!SCENE && h.mapGroup && h.mapGroup.group) {
      var m = h.mapGroup.group, k = 0;
      while (m && k++ < 24) { if (m.isScene) { SCENE = m; break; } m = m.parent; }
    }
    return SCENE;
  }
  function cam() {
    var h = hook();
    if (!h) return null;
    CAM = h.cameraWalk || CAM;
    return CAM;
  }

  var AUD = null;
  function audio() {
    if (AUD) { if (AUD.state === 'suspended') AUD.resume(); return AUD; }
    try { AUD = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { AUD = null; }
    return AUD;
  }
  function noiseBuf(ctx, dur) {
    var n = Math.floor(ctx.sampleRate * dur);
    var b = ctx.createBuffer(1, n, ctx.sampleRate);
    var d = b.getChannelData(0);
    for (var i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
    return b;
  }
  function sfxWhoosh(heavy) {
    var ctx = audio(); if (!ctx) return;
    var t = ctx.currentTime;
    var src = ctx.createBufferSource();
    src.buffer = noiseBuf(ctx, heavy ? 0.34 : 0.2);
    var bp = ctx.createBiquadFilter();
    bp.type = 'bandpass'; bp.frequency.value = heavy ? 420 : 900; bp.Q.value = 1.1;
    bp.frequency.setValueAtTime(heavy ? 300 : 700, t);
    bp.frequency.exponentialRampToValueAtTime(heavy ? 1600 : 2200, t + (heavy ? 0.3 : 0.16));
    var g = ctx.createGain();
    g.gain.setValueAtTime(heavy ? 0.36 : 0.22, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + (heavy ? 0.33 : 0.19));
    src.connect(bp); bp.connect(g); g.connect(ctx.destination);
    src.start(t);
  }
  function sfxClang(big) {
    var ctx = audio(); if (!ctx) return;
    var t = ctx.currentTime;
    var g = ctx.createGain();
    g.gain.setValueAtTime(big ? 0.5 : 0.34, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
    var o1 = ctx.createOscillator(); o1.type = 'triangle'; o1.frequency.setValueAtTime(big ? 900 : 1500, t);
    o1.frequency.exponentialRampToValueAtTime(big ? 220 : 420, t + 0.2);
    var o2 = ctx.createOscillator(); o2.type = 'square'; o2.frequency.setValueAtTime(big ? 2600 : 3900, t);
    o2.frequency.exponentialRampToValueAtTime(600, t + 0.14);
    var nz = ctx.createBufferSource(); nz.buffer = noiseBuf(ctx, 0.12);
    var nf = ctx.createBiquadFilter(); nf.type = 'highpass'; nf.frequency.value = 1600;
    var ng = ctx.createGain(); ng.gain.value = big ? 0.4 : 0.25;
    o1.connect(g); o2.connect(g); nz.connect(nf); nf.connect(ng); ng.connect(g);
    g.connect(ctx.destination);
    o1.start(t); o2.start(t); nz.start(t);
    o1.stop(t + 0.24); o2.stop(t + 0.2);
  }
  function sfxHit() {
    var ctx = audio(); if (!ctx) return;
    var t = ctx.currentTime;
    var g = ctx.createGain(); g.gain.setValueAtTime(0.28, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
    var o = ctx.createOscillator(); o.type = 'sine'; o.frequency.setValueAtTime(320, t);
    o.frequency.exponentialRampToValueAtTime(90, t + 0.09);
    o.connect(g); g.connect(ctx.destination); o.start(t); o.stop(t + 0.11);
  }

  var shakeUntil = 0;
  function shake(ms) { shakeUntil = Math.max(shakeUntil, performance.now() + ms); }
  var fxLayer = null;
  function comicWord(text, color) {
    if (!fxLayer) return;
    var w = $('div', 'modfxcw', text);
    w.style.color = color || '#f5b82a';
    w.style.left = (46 + Math.random() * 8) + '%';
    w.style.top = (42 + Math.random() * 10) + '%';
    w.style.setProperty('--rot', (Math.random() * 26 - 13) + 'deg');
    fxLayer.appendChild(w);
    setTimeout(function () { w.remove(); }, 520);
  }

  var KKEY = { code: 'KeyX', label: 'X' };
var PADS = { ready: false, btns: {} };
var KBIND = false;
var KNIFE = {
    out: false, swingT: -1, swingDur: 0.34, heavy: false, cool: 0,
    group: null, pivot: null, tip: null, hitDone: true
  };

  function buildKnife() {
    if (KNIFE.group || !THREE || !window.CLANG_PARTS) return;
    var c = cam(); if (!c) return;
    var k = window.CLANG_PARTS.knife(THREE);
    k.group.visible = false;
    c.add(k.group);
    KNIFE.group = k.group; KNIFE.pivot = k.pivot; KNIFE.tip = k.tip;
  }
  function hideGunsNow() {
    var h = hook(); if (!h || !h.weapons) return;
    var ws = h.weapons.weapons || [];
    for (var i = 0; i < ws.length; i++) {
      var vg = ws[i] && ws[i].view && ws[i].view.group;
      if (vg) vg.visible = false;
      var sg = ws[i] && ws[i].view && ws[i].view.switchGroup;
      if (sg) sg.visible = false;
    }
  }
  function patchRender() {
    var h = hook(); if (!h || !h.renderer) return;
    var r = h.renderer;
    if (r.__clangModWrap) return;
    r.__clangModWrap = true;
    var orig = r.render.bind(r);
    r.render = function (sc, cam) {
      if (KNIFE.out) hideGunsNow();
      return orig(sc, cam);
    };
  }
  function setGunVisible(v) {
    var h = hook(); if (!h || !h.weapons) return;
    var ws = h.weapons.weapons || [];
    for (var i = 0; i < ws.length; i++) {
      var vg = ws[i] && ws[i].view && ws[i].view.group;
      if (vg) vg.visible = v;
    }
  }
  function toggleKnife(on) {
    var next = on == null ? !KNIFE.out : !!on;
    KNIFE.out = next;
    buildKnife();
    if (KNIFE.group) KNIFE.group.visible = next;
    if (next) { KNIFE.pivot.rotation.set(-0.16, -0.42, 0.28); sfxWhoosh(false); }
    else setGunVisible(true);
    hudChip();
    audio();
  }
  function swingCombo() {
    var now = performance.now();
    if (now - (KNIFE.tapAt || 0) > 2400) KNIFE.comboN = 0;
    KNIFE.tapAt = now;
    KNIFE.comboN = (KNIFE.comboN || 0) + 1;
    startSwing(KNIFE.comboN > 1);
  }
  function startSwing(heavy) {
    if (!KNIFE.out || KNIFE.swingT >= 0 || performance.now() < (KNIFE.readyAt || 0)) return;
    KNIFE.heavy = !!heavy;
    KNIFE.swingT = 0;
    KNIFE.swings = (KNIFE.swings || 0) + 1;
    KNIFE.swingDur = heavy ? 0.6 : 0.34;
    KNIFE.hitDone = false;
    sfxWhoosh(heavy);
  }
  function knifePose(t) {
    var p = KNIFE.pivot;
    if (!p) return;
    var base = { px: 0.38, py: -0.34, pz: -0.47, rx: -1.25, ry: 0.05, rz: -0.32 };
    if (t < 0) { p.position.set(0, -0.02, 0); p.rotation.set(base.rx, base.ry, base.rz); KNIFE.group.position.set(base.px, base.py, base.pz); return; }
    var k;
    if (!KNIFE.heavy) {
      if (t < 0.3) { k = t / 0.3; p.rotation.set(lerp(base.rx, -1.55, k), lerp(base.ry, -0.35, k), lerp(base.rz, -0.10, k)); KNIFE.group.position.set(lerp(base.px, 0.44, k), lerp(base.py, -0.28, k), lerp(base.pz, -0.44, k)); }
      else if (t < 0.62) { k = (t - 0.3) / 0.32; p.rotation.set(lerp(-1.55, -0.85, k), lerp(-0.35, 1.05, k), lerp(-0.10, -0.60, k)); KNIFE.group.position.set(lerp(0.44, 0.03, k), lerp(-0.28, -0.38, k), lerp(-0.44, -0.52, k)); }
      else { k = (t - 0.62) / 0.38; p.rotation.set(lerp(-0.85, base.rx, k), lerp(1.05, base.ry, k), lerp(-0.75, base.rz, k)); KNIFE.group.position.set(lerp(0.05, base.px, k), lerp(-0.50, base.py, k), lerp(-0.52, base.pz, k)); }
    } else {
      if (t < 0.24) { k = t / 0.24; p.rotation.set(lerp(base.rx, -1.75, k), lerp(base.ry, -0.60, k), lerp(base.rz, 0.15, k)); KNIFE.group.position.set(lerp(base.px, 0.50, k), lerp(base.py, -0.20, k), lerp(base.pz, -0.40, k)); }
      else if (t < 0.46) { k = (t - 0.24) / 0.22; p.rotation.set(lerp(-1.75, -0.62, k), lerp(-0.60, 1.50, k), lerp(0.15, -0.90, k)); KNIFE.group.position.set(lerp(0.50, -0.06, k), lerp(-0.20, -0.46, k), lerp(-0.40, -0.55, k)); }
      else if (t < 0.62) { k = (t - 0.46) / 0.16; p.rotation.set(lerp(-0.62, -1.0, k), lerp(1.50, 0.45, k), lerp(-0.90, -0.55, k)); KNIFE.group.position.set(lerp(-0.05, 0.10, k), lerp(-0.54, -0.46, k), lerp(-0.55, -0.50, k)); }
      else { k = (t - 0.62) / 0.38; p.rotation.set(lerp(-1.0, base.rx, k), lerp(0.45, base.ry, k), lerp(-0.55, base.rz, k)); KNIFE.group.position.set(lerp(0.10, base.px, k), lerp(-0.46, base.py, k), lerp(-0.50, base.pz, k)); }
    }
  }

  var hitAcc = { list: [], t: 0 };
  function meleeStrike() {
    var h = hook(); if (!h || !h.run || !h.player) return 0;
    var ms = h.run.machines || [];
    var pl = h.player.position;
    if (!pl) return 0;
    var c = cam();
    var fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(c.quaternion);
    fwd.y = 0;
    if (fwd.lengthSq() < 1e-6) return 0;
    fwd.normalize();
    var range = KNIFE.heavy ? 3.1 : 2.5;
    var arc = KNIFE.heavy ? 1.15 : 0.9;
    var hits = 0, kills = 0;
    for (var i = 0; i < ms.length; i++) {
      var m = ms[i];
      if (!m || m.dead || !m.pos) continue;
      var dx = m.pos.x - pl.x, dz = m.pos.z - pl.z;
      var d = Math.hypot(dx, dz);
      var hh = (m.stats && m.stats.height) || 1.8;
      if (d > range + 0.55) continue;
      var dirDot = d < 0.35 ? 1 : (dx * fwd.x + dz * fwd.z) / d;
      if (dirDot < Math.cos(arc)) continue;
      var dy = Math.abs((m.pos.y + hh * 0.5) - (pl.y + 0.2));
      if (dy > hh * 0.85) continue;
      var headY = m.pos.y + hh * 0.82;
      var head = Math.abs(headY - (pl.y + 0.72)) < 0.5 || (dy < hh * 0.3);
      var back = (dx * Math.sin(m.yaw) + dz * Math.cos(m.yaw)) > 0.2;
      var dmg = (KNIFE.heavy ? 165 : 92) * (head ? 2 : 1) * (back ? 1.6 : 1);
      try {
        m.takeDamage(dmg, head ? 'head' : 'body');
        if (m.dead) kills++;
      } catch (e) { }
      hits++;
      sparkAt(m.pos.x, m.pos.y + hh * 0.55, m.pos.z, head);
    }
    KNIFE.cool = KNIFE.heavy ? 0.62 : 0.26;
    KNIFE.readyAt = performance.now() + (KNIFE.heavy ? 640 : 250);
    KNIFE.hits = (KNIFE.hits || 0) + hits;
    if (hits) {
      sfxClang(KNIFE.heavy);
      sfxHit();
      shake(KNIFE.heavy ? 190 : 110);
      comicWord(kills ? '拆 碎!' : (KNIFE.heavy ? '轰!' : '哐!'), kills ? '#ff5a3c' : '#f5b82a');
      meanHitStop(KNIFE.heavy ? 0.08 : 0.05);
      netSendMelee(hits, kills);
    } else if (KNIFE.heavy) {
      shake(60);
    }
    return hits;
  }
  function meanHitStop(sec) {
    if (mpHitStopT > 0) return;
    mpHitStopT = sec;
  }
  var mpHitStopT = 0;

  var sparkPool = [], sparkGeo = null;
  function initFx() {
    if (sparkGeo || !THREE || !SCENE) return;
    fxLayer = $('div', 'modfx'); SHADOW.appendChild(fxLayer);
  }
  function sparkAt(x, y, z, big) {
    if (!THREE || !SCENE) return;
    var g = new THREE.Group();
    var mat = new THREE.MeshBasicMaterial({ color: big ? 0xffd36b : 0xffb648, transparent: true, opacity: 1, blending: THREE.AdditiveBlending, depthWrite: false, fog: false });
    for (var i = 0; i < (big ? 10 : 6); i++) {
      var s = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.03, 0.12), mat);
      s.position.set(x, y, z);
      var a = Math.random() * Math.PI * 2, sp = 3 + Math.random() * 6;
      s.userData.v = new THREE.Vector3(Math.cos(a) * sp * 0.35, Math.random() * sp, Math.sin(a) * sp * 0.35);
      g.add(s);
    }
    g.userData.age = 0;
    SCENE.add(g);
    sparkPool.push(g);
  }
  function stepFx(dt) {
    for (var i = sparkPool.length - 1; i >= 0; i--) {
      var g = sparkPool[i];
      g.userData.age += dt;
      var k = g.userData.age / 0.42;
      if (k >= 1) { SCENE.remove(g); sparkPool.splice(i, 1); continue; }
      for (var j = 0; j < g.children.length; j++) {
        var ch = g.children[j];
        ch.position.addScaledVector(ch.userData.v, dt);
        ch.userData.v.y -= 12 * dt;
        ch.rotation.x += dt * 9;
        ch.material.opacity = 1 - k;
      }
    }
  }

  var NET = {
    on: false, ws: null, url: '', room: 'CLANG', name: '', id: '',
    players: new Map(), selfIdx: null, self: { armor: 100, kills: 0, deaths: 0, down: false, respawnAt: 0 },
    lastSend: 0, sendHz: 20, ping: 0, lastPingAt: 0, log: [], lastShotAmmo: -1, lastShotId: '',
    joined: false, autoConnect: false,
    host: '', enAt: 0, enList: null, enWrap: 0
  };
  function uuid() {
    var s = 'xxxxxxxxxxxx'.replace(/x/g, function () { return Math.floor(Math.random() * 16).toString(16); });
    return s;
  }
  function wsUrl() {
    var proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    if (location.host && location.protocol.indexOf('http') === 0) return proto + '//' + location.host;
    return proto + '//127.0.0.1:8787';
  }
  function netConnect(url, room, name) {
    url = String(url || '').trim().replace(/\/relay\/?$/i, '').replace(/\/?$/, '');
    netDisconnect();
    NET.msg = '连接中…';
    clearTimeout(NET.tm);
    NET.tm = setTimeout(function () {
      if (!NET.on) {
        NET.msg = '连接超时：检查中继地址、端口转发协议是否为 TCP';
        if (mpEls.lobby) mpEls.lobby.hidden = false;
        mpHud();
      }
    }, 4500);
    NET.url = url || wsUrl();
    NET.room = (room || 'CLANG').slice(0, 16);
    NET.name = (name || '拆机工').slice(0, 12);
    NET.id = NET.id || uuid();
    try { NET.ws = new WebSocket(NET.url); } catch (e) { netLog('地址无效'); return; }
    NET.ws.onopen = function () {
      NET.on = true;
      NET.msg = '';
      clearTimeout(NET.tm);
      NET.ws.send(JSON.stringify({ t: 'join', room: NET.room, id: NET.id, name: NET.name }));
      NET.joined = true;
      netLog('已连接 ' + NET.url);
      mpHud();
      try { localStorage.setItem('clang.mp.url', NET.url); localStorage.setItem('clang.mp.room', NET.room); localStorage.setItem('clang.mp.name', NET.name); } catch (e) { }
    };
    NET.ws.onerror = function () {
      if (!NET.on) {
        NET.msg = '连接被拒：中继端口没转发或非 TCP';
        clearTimeout(NET.tm);
        if (mpEls.lobby) mpEls.lobby.hidden = false;
        mpHud();
      }
    };
    NET.ws.onclose = function () {
      if (!NET.on && !NET.msg) { NET.msg = '连不上中继'; if (mpEls.lobby) mpEls.lobby.hidden = false; }
      NET.on = false; NET.joined = false;
      netLog('连接断开');
      clearRemotes();
      mpHud();
    };
    NET.ws.onerror = function () { netLog('连接出错'); };
    NET.ws.onmessage = function (ev) {
      var d; try { d = JSON.parse(ev.data); } catch (e) { return; }
      onNet(d);
    };
  }
  function netDisconnect() {
    if (NET.ws) { try { NET.ws.close(); } catch (e) { } }
    NET.ws = null; NET.on = false; NET.joined = false;
    clearRemotes();
    mpHud();
  }
  function netSend(o) {
    if (!NET.on || !NET.ws || NET.ws.readyState !== 1) return;
    try { NET.ws.send(JSON.stringify(o)); } catch (e) { }
  }
  function netLog(s) {
    NET.log.push({ t: performance.now(), s: s });
    if (NET.log.length > 5) NET.log.shift();
    mpHud();
  }

  function avatarColor(i) {
    var cols = [0xf5b82a, 0x4fb3d9, 0xd9534f, 0x8fce4f, 0xc56bdd, 0xe08a3c];
    return cols[i % cols.length];
  }
  function buildAvatar(name, idx, id) {
    if (!THREE || !window.CLANG_PARTS) return null;
    var g = window.CLANG_PARTS.avatar(THREE, name, idx, id);
    if (SCENE) SCENE.add(g);
    return g;
  }
  function makeNameSprite(name, col) {
    var c = document.createElement('canvas');
    c.width = 256; c.height = 64;
    var x = c.getContext('2d');
    x.fillStyle = 'rgba(20,16,12,.82)';
    x.fillRect(0, 0, 256, 64);
    x.fillStyle = '#' + ('000000' + col.toString(16)).slice(-6);
    x.fillRect(0, 0, 8, 64);
    x.font = 'bold 30px Bahnschrift, "Microsoft YaHei", sans-serif';
    x.fillStyle = '#efe4cc';
    x.textBaseline = 'middle';
    x.fillText(name, 18, 34);
    var tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    var mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, fog: false });
    var sp = new THREE.Sprite(mat);
    sp.scale.set(1.9, 0.475, 1);
    sp.renderOrder = 50;
    return sp;
  }
  function pickHost() {
    var best = NET.id, bIdx = NET.selfIdx == null ? 0 : NET.selfIdx;
    NET.players.forEach(function (r) {
      var i = (r.idx == null) ? 9999 : r.idx;
      if (i < bIdx || (i === bIdx && r.id < best)) { bIdx = i; best = r.id; }
    });
    return best || NET.id;
  }
  function isHost() { return !NET.on || NET.host === NET.id; }
  function enemyKey(m, i) { return (m && m.id != null) ? m.id : ('i' + i); }
  function enemySnapshot() {
    var h = hook();
    if (!h || !h.run || !h.run.machines) return null;
    var ms = h.run.machines, alive = [], dead = [];
    for (var i = 0; i < ms.length; i++) {
      var m = ms[i];
      if (!m || !m.pos) continue;
      var row = [enemyKey(m, i), Math.round(m.pos.x * 100) / 100, Math.round(m.pos.y * 100) / 100, Math.round(m.pos.z * 100) / 100, Math.round((m.yaw || 0) * 100) / 100, (m.dead || m.alive === false) ? 0 : 1, Math.max(0, Math.round(m.hp || 0))];
      if (row[5]) alive.push(row); else dead.push(row);
    }
    return alive.concat(dead).slice(0, 52);
  }
  function enemyLookup() {
    var h = hook(), map = {};
    if (!h || !h.run || !h.run.machines) return map;
    var ms = h.run.machines;
    for (var i = 0; i < ms.length; i++) { if (ms[i]) map[enemyKey(ms[i], i)] = ms[i]; }
    return map;
  }
  function applyEnemySnapshot(list) {
    if (!list || !list.length) return;
    var map = enemyLookup();
    for (var j = 0; j < list.length; j++) {
      var e = list[j], m = map[e[0]];
      if (!m || !m.pos) continue;
      if (!e[5]) {
        if (!m.dead && m.alive !== false) { try { m.takeDamage(1e7, 'blast'); } catch (_) { } }
        continue;
      }
      m.pos.set(e[1], e[2], e[3]);
      if (m.yaw != null) m.yaw = e[4];
      if (e[6] > 0 && m.hp != null) m.hp = e[6];
    }
  }
  function wrapEnemyDamage() {
    var h = hook();
    if (!h || !h.run || !h.run.machines) return;
    var ms = h.run.machines;
    for (var i = 0; i < ms.length; i++) {
      var m = ms[i];
      if (!m || m.__netHit) continue;
      m.__netHit = true;
      (function (mm, key) {
        var orig = mm.takeDamage.bind(mm);
        mm.takeDamage = function (dmg, zone) {
          if (NET.on && !isHost()) netSend({ t: 'ehit', k: key, d: Math.round(dmg || 0) });
          return orig(dmg, zone);
        };
      })(m, enemyKey(m, i));
    }
  }
  function applyEnemyHit(k, dmg) {
    if (!NET.on) return;
    var m = enemyLookup()[k];
    if (!m || m.dead) return;
    try { m.takeDamage(dmg, 'body'); } catch (_) { }
  }

  function clearRemotes() {
    NET.players.forEach(function (p) {
      if (p.obj && p.obj.parent) p.obj.parent.remove(p.obj);
    });
    NET.players.clear();
  }

  function onNet(d) {
    if (!d || !d.t) return;
    if (d.t === 'roster' || d.t === 'welcome') {
      var seen = {};
      (d.players || []).forEach(function (pl) {
        seen[pl.id] = 1;
        if (pl.id === NET.id) { NET.selfIdx = pl.idx; return; }
        var rec = NET.players.get(pl.id);
        if (!rec) {
          rec = { id: pl.id, name: pl.name, idx: pl.idx, obj: null, last: performance.now(), ping: 0, kills: 0, deaths: 0 };
          NET.players.set(pl.id, rec);
        }
        if (!rec.obj) rec.obj = buildAvatar(rec.name || '工友', rec.idx || 0, rec.id);
        if (rec.obj && !rec.obj.parent && SCENE) SCENE.add(rec.obj);
      });
      NET.players.forEach(function (rec, id) { if (!seen[id]) { if (rec.obj && rec.obj.parent) rec.obj.parent.remove(rec.obj); NET.players.delete(id); } });
      NET.host = pickHost();
      mpHud();
      return;
    }
    if (d.t === 'left') {
      var r = NET.players.get(d.id);
      if (r) { if (r.obj && r.obj.parent) r.obj.parent.remove(r.obj); NET.players.delete(d.id); }
      NET.host = pickHost();
      mpHud();
      return;
    }
    if (d.t === 'en') {
      if (!isHost() && d.list) NET.enList = d.list;
      return;
    }
    if (d.t === 'ehit') {
      if (isHost()) applyEnemyHit(d.k, d.d || 1);
      return;
    }
    if (d.t === 's') {
      var rec = NET.players.get(d.from);
      if (!rec) return;
      rec.last = performance.now();
      rec.obj.userData.target.set(d.x, d.y, d.z);
      rec.obj.userData.tYaw = d.yaw;
      rec.obj.userData.speed = d.sp || 0;
      rec.obj.userData.knife = !!d.k;
      if (d.hp != null) { rec.hp = d.hp; rec.kills = d.kill || 0; rec.deaths = d.death || 0; }
      return;
    }
    if (d.t === 'shot') {
      var rr = NET.players.get(d.from);
      if (!rr) return;
      tracer(d.o, d.d, 0xfff0a0);
      rr.obj.userData.flash = 0.07;
      muteShot(d.w);
      return;
    }
    if (d.t === 'hit') {
      if (d.to === NET.id) { selfHit(d.dmg, d.w, d.from); }
      return;
    }
    if (d.t === 'down') {
      if (d.to === NET.id) selfDown(d.by);
      else {
        var pr = NET.players.get(d.to);
        if (pr) comicWorld(pr.obj.position, '拆 倒', '#ff5a3c');
      }
      return;
    }
    if (d.t === 'knife') {
      var kr = NET.players.get(d.from);
      if (kr) { slashFx(kr.obj.position, 0xffcf6b); muteClash(); }
      return;
    }
    if (d.t === 'score') {
      if (d.kills != null) NET.self.kills = d.kills;
      if (d.deaths != null) NET.self.deaths = d.deaths;
      return;
    }
    if (d.t === 'chat') { netLog((d.name || '?') + '：' + String(d.msg || '').slice(0, 80)); return; }
    if (d.t === 'pong') { NET.ping = Math.round(performance.now() - d.at); return; }
    if (d.t === 'ping') { netSend({ t: 'pong', at: d.at, to: d.from }); return; }
  }

  var traces = [];
  function tracer(o, dir, color) {
    if (!THREE || !SCENE) return;
    var from = new THREE.Vector3(o[0], o[1], o[2]);
    var dv = new THREE.Vector3(dir[0], dir[1], dir[2]).normalize();
    var len = 90;
    var to = from.clone().addScaledVector(dv, len);
    var geo = new THREE.BufferGeometry().setFromPoints([from, to]);
    var mat = new THREE.LineBasicMaterial({ color: color || 0xfff0a0, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false, fog: false });
    var line = new THREE.Line(geo, mat);
    line.frustumCulled = false;
    SCENE.add(line);
    traces.push({ obj: line, age: 0 });
  }
  function slashFx(pos, color) {
    if (!THREE || !SCENE) return;
    var m = new THREE.Mesh(new THREE.TorusGeometry(0.55, 0.035, 6, 18, Math.PI * 1.1), new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 1, blending: THREE.AdditiveBlending, depthWrite: false, fog: false }));
    m.position.set(pos.x, pos.y + 1.2, pos.z);
    m.rotation.set(Math.PI * 0.5, Math.random() * 3, Math.random() * 3);
    SCENE.add(m);
    sparkPool.push(Object.assign(m, { userData: { age: 0 } }));
    m.userData.v = new THREE.Vector3();
  }
  function comicWorld(pos, text, color) {
    if (!THREE || !SCENE || !CAM) return;
    var v = new THREE.Vector3(pos.x, pos.y + 1.9, pos.z).project(CAM);
    if (v.z > 1) return;
    var sx = (v.x * 0.5 + 0.5) * 100, sy = (-v.y * 0.5 + 0.5) * 100;
    var w = $('div', 'modfxcw', text);
    w.style.color = color; w.style.left = sx + '%'; w.style.top = sy + '%';
    fxLayer.appendChild(w);
    setTimeout(function () { w.remove(); }, 520);
  }
  function muteShot(w) {
    if (w === 'sniper') return;
  }
  function muteClash() { }

  function selfHit(dmg, w, from) {
    if (NET.self.down) return;
    NET.self.armor = Math.max(0, NET.self.armor - dmg);
    hurtFlash();
    sfxHit();
    shake(90);
    var rec = NET.players.get(from);
    if (NET.self.armor <= 0) {
      NET.self.down = true;
      NET.self.deaths++;
      NET.self.respawnAt = performance.now() + 3200;
      netSend({ t: 'down', to: NET.id, by: from, kill: 1 });
      netSend({ t: 'score', kills: NET.self.kills, deaths: NET.self.deaths });
      comicWord('被 拆 了', '#ff5a3c');
      downs();
    }
  }
  function selfDown(by) {
    NET.self.kills++;
    netSend({ t: 'score', kills: NET.self.kills, deaths: NET.self.deaths });
    comicWord('拆 掉 一 个', '#8fce4f');
    killfeed((NET.players.get(by) || {}).name || '工友', NET.name);
  }
  function killfeed(a, b) {
    var k = $('div', 'modkill', '');
    k.innerHTML = '<b>' + esc(a) + '</b> ⟶ <b>' + esc(b) + '</b>';
    (mpKillLayer || document.body).appendChild(k);
    setTimeout(function () { k.remove(); }, 3200);
  }
  function esc(s) { return String(s || '').replace(/[<>&]/g, function (c) { return { '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c]; }); }

  var hurtEl = null;
  function hurtFlash() {
    if (!hurtEl) { hurtEl = $('div', 'modhurt'); SHADOW.appendChild(hurtEl); }
    hurtEl.classList.remove('on');
    void hurtEl.offsetWidth;
    hurtEl.classList.add('on');
  }

  function netSendState() {
    var h = hook(); if (!h || !h.player) return;
    var p = h.player.position, st = h.state;
    var sp = h.player.horizontalSpeed || 0;
    netSend({
      t: 's', x: +p.x.toFixed(2), y: +(h.player.feetY || 0).toFixed(2), z: +p.z.toFixed(2),
      yaw: +(st.yaw || 0).toFixed(2), sp: +sp.toFixed(1),
      k: KNIFE.out ? 1 : 0, hp: NET.self.armor,
      kill: NET.self.kills, death: NET.self.deaths
    });
  }
  function netSendMelee(hits, kills) {
    if (!NET.on) return;
    var h = hook();
    var c = cam(); if (!c) return;
    var p = c.getWorldPosition(new THREE.Vector3());
    var d = new THREE.Vector3(0, 0, -1).applyQuaternion(c.quaternion);
    netSend({ t: 'knife', o: [+p.x.toFixed(2), +p.y.toFixed(2), +p.z.toFixed(2)], d: [+d.x.toFixed(2), +d.y.toFixed(2), +d.z.toFixed(2)], hits: hits });
    pvpKnife(d);
  }
  function pvpKnife(dir) {
    if (!NET.on) return;
    var h = hook(); var pl = h.player.position;
    NET.players.forEach(function (rec) {
      if (performance.now() - rec.last > 3000) return;
      var o = rec.obj.position;
      var dx = o.x - pl.x, dz = o.z - pl.z, d = Math.hypot(dx, dz);
      if (d > 2.9) return;
      var dot = (dx * dir.x + dz * dir.z) / Math.max(0.001, d);
      if (dot < 0.35) return;
      var dmg = (KNIFE.heavy ? 120 : 72) * (rec.obj.userData.knife ? 1 : 1);
      netSend({ t: 'hit', to: rec.id, dmg: dmg, w: 'knife' });
      comicWorld(o, '砍!', '#f5b82a');
    });
  }
  function localShotDetect() {
    var h = hook(); if (!h || !h.weapons || !h.weapons.active) return;
    var a = h.weapons.active;
    var ammo = a.ammoInMagazine, id = a.config ? a.config.id : '';
    if (NET.lastShotId !== id) { NET.lastShotId = id; NET.lastShotAmmo = ammo; return; }
    if (ammo < NET.lastShotAmmo && !KNIFE.out && NET.on) {
      var c = cam();
      var p = c.getWorldPosition(new THREE.Vector3());
      var d = new THREE.Vector3(0, 0, -1).applyQuaternion(c.quaternion).normalize();
      netSend({ t: 'shot', w: id, o: [+p.x.toFixed(2), +p.y.toFixed(2), +p.z.toFixed(2)], d: [+d.x.toFixed(2), +d.y.toFixed(2), +d.z.toFixed(2)] });
      pvpShot(p, d, id);
    }
    NET.lastShotAmmo = ammo;
  }
  function pvpShot(origin, dir, id) {
    var dmgTable = { rifle: 16, pistol: 26, shotgun: 44, sniper: 88 };
    var base = dmgTable[id] || 20;
    NET.players.forEach(function (rec) {
      if (performance.now() - rec.last > 3000) return;
      var o = rec.obj.position;
      var feet = new THREE.Vector3(o.x, o.y, o.z);
      var head = feet.clone(); head.y += 1.66;
      var body = feet.clone(); body.y += 1.1;
      var hitHead = rayNear(origin, dir, head, 0.32);
      var hitBody = hitHead || rayNear(origin, dir, body, 0.42);
      if (!hitBody) return;
      var d = Math.round(base * (hitHead ? 2 : 1));
      netSend({ t: 'hit', to: rec.id, dmg: d, w: id });
      sparkAt(head.x, head.y - 0.5, head.z, hitHead);
      comicWorld(o, hitHead ? '爆 头' : '命 中', hitHead ? '#ff5a3c' : '#efe4cc');
    });
  }
  function rayNear(o, d, p, r) {
    var op = new THREE.Vector3(p.x - o.x, p.y - o.y, p.z - o.z);
    var proj = op.dot(d);
    if (proj < 0 || proj > 120) return false;
    var perp = op.clone().addScaledVector(d, -proj).length();
    return perp <= r;
  }

  function stepNet(dt) {
    if (!NET.on) return;
    var now = performance.now();
    if (now - NET.lastSend > 1000 / NET.sendHz) { NET.lastSend = now; netSendState(); }
    if (isHost()) {
      if (now - NET.enAt > 90) { NET.enAt = now; var en = enemySnapshot(); if (en) { netSend({ t: 'en', list: en }); NET.enSent = (NET.enSent || 0) + 1; } }
    } else {
      wrapEnemyDamage();
      if (NET.enList) { applyEnemySnapshot(NET.enList); NET.enApplied = (NET.enApplied || 0) + 1; NET.enList = null; }
    }
    localShotDetect();
    NET.players.forEach(function (rec) {
      if (!rec.obj) rec.obj = buildAvatar(rec.name || '工友', rec.idx || 0, rec.id);
      if (!rec.obj) return;
      if (!rec.obj.parent && SCENE) SCENE.add(rec.obj);
      var ob = rec.obj, u = ob.userData;
      ob.visible = true;
      var k = 1 - Math.exp(-12 * dt);
      u.cur.lerp(u.target, k);
      ob.position.copy(u.cur);
      var dyaw = (u.tYaw || 0) - u.yawCur;
      while (dyaw > Math.PI) dyaw -= Math.PI * 2;
      while (dyaw < -Math.PI) dyaw += Math.PI * 2;
      u.yawCur += dyaw * Math.min(1, 10 * dt);
      ob.rotation.y = u.yawCur;
      var ph = performance.now() / 1000 * 6 + (u.idx || 0) * 1.7;
      var amp = clamp((u.speed || 0) / 4, 0, 1) * 0.5;
      u.legL.rotation.x = Math.sin(ph) * amp;
      u.legR.rotation.x = -Math.sin(ph) * amp;
      u.armL.rotation.x = -Math.sin(ph) * amp * 0.6;
      u.armR.rotation.x = Math.sin(ph) * amp * 0.6;
      if (u.flash > 0) { u.flash -= dt; }
      if (NET.self.down) return;
    });
    if (NET.self.down && now > NET.self.respawnAt) respawnSelf();
    if (now - NET.lastPingAt > 2000) { NET.lastPingAt = now; netSend({ t: 'ping', at: now }); }
    NET.self.armor = Math.min(100, NET.self.armor + dt * (NET.self.down ? 0 : 4));
    mpHud();
  }
  function respawnSelf() {
    NET.self.down = false; NET.self.armor = 100;
    var h = hook();
    if (h && h.player && h.player.position && h.player.velocity) {
      h.player.position.set(0, 0.94, 42);
      h.player.velocity.set(0, 0, 0);
      h.player.feetY = 0.04;
    }
    ups();
    comicWord('重 返 战 场', '#8fce4f');
  }

  var mpEls = { root: null, chip: null, list: null, armor: null, state: null, board: null, kill: null, lobby: null };
  var mpKillLayer = null;
  function buildHud() {
    var root = $('div', 'modhud');
    root.setAttribute('translate', 'no');
    root.setAttribute('lang', 'zh-CN');
    var chip = $('div', 'modchip');
    chip.innerHTML = '<b>MOD</b><span class="dot"></span><i>X</i>刀<i>P</i>联机<i>B</i>战绩';
    setTimeout(function () { chip.classList.add('dim'); }, 12000);
    root.appendChild(chip);
    SHADOW.appendChild(root);
    mpEls.root = root; mpEls.chip = chip;

    mpKillLayer = $('div', 'modkillfeed');
    mpKillLayer.setAttribute('translate', 'no');
    mpKillLayer.setAttribute('lang', 'zh-CN');
    SHADOW.appendChild(mpKillLayer);

    var mp = $('div', 'modmp');
    mp.setAttribute('translate', 'no');
    mp.setAttribute('lang', 'zh-CN');
    mp.innerHTML =
      '<div class="modmp-head"><span class="modmp-title">联机 · 拆机乱斗</span><button class="modmp-x">×</button></div>' +
      '<div class="modmp-body">' +
      '<div class="modmp-rows">' +
      '<label>中继地址<input class="modmp-url" spellcheck="false"></label>' +
      '<label>房间码<input class="modmp-room" maxlength="16" spellcheck="false"></label>' +
      '<label>呼号<input class="modmp-name" maxlength="12" spellcheck="false"></label>' +
      '</div>' +
      '<div class="modmp-state">未连接</div>' +
      '<div class="modmp-actions"><button class="modmp-go">加入房间</button><button class="modmp-out">断开</button></div>' +
      '<div class="modmp-keyrow"><span>刀键</span><button class="modmp-bind">X</button><small>点一下再按任意键即可改</small></div>' +
      '<div class="modmp-knife"><b>近战刀</b>：电脑按 <i>X</i> 拔刀，左键轻砍、右键重砍；手机点【刀】拔刀，再点【砍】：第一下轻砍，连点第二下起都是重砍，停手 2.4 秒后重新从轻砍开始。</div>' +
      '<div class="modmp-rule">服务器只转发字节流；位置、命中、伤害全部由各自客户端计算。</div>' +
      '<div class="modmp-list"></div>' +
      '<div class="modmp-log"></div>' +
      '</div>';
    var mask = $('div', 'modmask');
    mask.hidden = true;
    mask.addEventListener('pointerdown', function (e) { e.stopPropagation(); e.preventDefault(); }, true);
    mask.addEventListener('click', function (e) { if (e.target === mask) { e.stopPropagation(); hideLobby(); } });
    mask.appendChild(mp);
    SHADOW.appendChild(mask);
    mpEls.mask = mask;
    mpEls.lobby = mask;
    mpEls.panel = mp;
    mpEls.list = mp.querySelector('.modmp-list');
    mpEls.state = mp.querySelector('.modmp-state');
    mpEls.go = mp.querySelector('.modmp-go');
    mpEls.bind = mp.querySelector('.modmp-bind');
    mpEls.knote = mp.querySelector('.modmp-knife');
    try { var ks = localStorage.getItem('clangKnifeKey'); if (ks) { KKEY.code = ks; KKEY.label = keyLabel(ks); } } catch (er) { }
    mpEls.bind.onclick = function (e) { e.stopPropagation(); KBIND = true; updateKBind(); };
    updateKBind();
    mpEls.lobby.querySelector('.modmp-x').onclick = function () { hideLobby(); };
    mpEls.go.onclick = function () {
      if (NET.on) { hideLobby(); var st = document.querySelector('#start'); if (st && !document.body.classList.contains('walking')) { try { st.click(); } catch (e) { } } return; }
      var url = mp.querySelector('.modmp-url').value.trim();
      var room = mp.querySelector('.modmp-room').value.trim() || 'CLANG';
      var name = mp.querySelector('.modmp-name').value.trim() || '拆机工';
      netConnect(url, room, name);
    };
    mp.querySelector('.modmp-out').onclick = function () { netDisconnect(); };
    ['pointerdown', 'mousedown', 'mouseup', 'contextmenu'].forEach(function (t) {
      mp.addEventListener(t, function (e) { e.stopPropagation(); }, true);
    });
    mp.addEventListener('wheel', function (e) { e.stopPropagation(); }, { passive: true });
    mp.addEventListener('click', function (e) { e.stopPropagation(); }, false);
    try {
      mp.querySelector('.modmp-url').value = localStorage.getItem('clang.mp.url') || wsUrl();
      mp.querySelector('.modmp-room').value = localStorage.getItem('clang.mp.room') || 'CLANG';
      mp.querySelector('.modmp-name').value = localStorage.getItem('clang.mp.name') || ('工' + Math.floor(Math.random() * 90 + 10));
    } catch (e) { mp.querySelector('.modmp-url').value = wsUrl(); }

    var hud = $('div', 'modmphud');
    hud.innerHTML = '<div class="modmphud-av"><span class="modmphud-armor"></span></div><div class="modmphud-right"><div class="modmphud-score">0 / 0</div><div class="modmphud-ping">-- ms</div></div>';
    root.appendChild(hud);
    mpEls.armor = hud.querySelector('.modmphud-armor');
    mpEls.score = hud.querySelector('.modmphud-score');
    mpEls.ping = hud.querySelector('.modmphud-ping');

    var board = $('div', 'modboard');
    board.setAttribute('translate', 'no');
    board.setAttribute('lang', 'zh-CN');
    board.innerHTML = '<div class="modboard-box"><div class="modboard-title">拆机乱斗 · 战绩</div><div class="modboard-rows"></div></div>';
    SHADOW.appendChild(board);
    mpEls.board = board;
    board.hidden = true;

    buildTouch();
    syncMenuTab();
  }
  function ensureSceneReady() {
    var html = document.documentElement;
    if (html.classList.contains('scene-ready')) {
      try { if (document.body.classList.contains('walking')) { sessionStorage.removeItem('clangCrashed'); sessionStorage.removeItem('clangCrashN'); } } catch (e) { }
      return;
    }
    var boot = document.querySelector('#boot');
    if (!boot) { html.classList.add('scene-ready'); return; }
    if (boot.classList.contains('failed')) return;
    if (boot.classList.contains('out') || SCENE) html.classList.add('scene-ready');
  }
  function isTouch() {
    try {
      if (document.body && document.body.classList.contains('touch-mode')) return true;
      if (window.matchMedia && matchMedia('(pointer:coarse)').matches) return true;
    } catch (e) { }
    return false;
  }
  function keyLabel(code) {
    if (!code) return 'X';
    if (/^Key[A-Z]$/.test(code)) return code.slice(3);
    if (/^Digit[0-9]$/.test(code)) return code.slice(5);
    if (/^Numpad[0-9]$/.test(code)) return code.slice(6);
    var m = { Space: '空格', ShiftLeft: '左Shift', ShiftRight: '右Shift', ControlLeft: '左Ctrl', ControlRight: '右Ctrl', AltLeft: '左Alt', AltRight: '右Alt', Escape: 'Esc', Tab: 'Tab', CapsLock: 'Caps', Enter: '回车', Backquote: '`', Minus: '-', Equal: '=', BracketLeft: '[', BracketRight: ']', Backslash: '\\', Semicolon: ';', Quote: "'", Comma: ',', Period: '.', Slash: '/' };
    return m[code] || code.replace(/Left|Right$/, '');
  }
  function updateKBind() {
    if (!mpEls.bind) return;
    mpEls.bind.textContent = KBIND ? '按任意键…' : KKEY.label;
    mpEls.bind.classList.toggle('wait', KBIND);
    if (mpEls.knote) mpEls.knote.innerHTML = '近战刀：电脑按 <b>' + KKEY.label + '</b> 拔刀 / 收刀，左右键轻砍重砍；手机点下方【刀】按钮。';
  }
  function hideLobby() {
    if (mpEls.lobby) mpEls.lobby.hidden = true;
    if (mpEls.mask) mpEls.mask.hidden = true;
  }
  function openLobby() {
    if (!mpEls.lobby) return;
    try { if (document.pointerLockElement && document.exitPointerLock) document.exitPointerLock(); } catch (e) { }
    mpEls.lobby.hidden = false;
    if (mpEls.mask) mpEls.mask.hidden = false;
    mpHud();
    try { var u = mpEls.lobby.querySelector('.modmp-url'); if (u && !u.value) u.value = wsUrl(); } catch (e) { }
  }
  function toggleBoard() {
    if (!mpEls.board) return;
    mpEls.board.hidden = !mpEls.board.hidden;
    if (!mpEls.board.hidden) renderBoard();
  }
  var TOUCH = { el: null };
  function buildTouch() {
    var t = $('div', 'modtouch');
    t.setAttribute('translate', 'no');
    t.setAttribute('lang', 'zh-CN');
    t.innerHTML = '<button type="button" class="mtb mtb-knife">刀</button>' +
      '<button type="button" class="mtb mtb-light">轻砍</button>' +
      '<button type="button" class="mtb mtb-heavy">重砍</button>' +
      '<button type="button" class="mtb mtb-net">联机</button>' +
      '<button type="button" class="mtb mtb-board">战绩</button>';
    SHADOW.appendChild(t);
    TOUCH.el = t;
    function tap(sel, fn) {
      var b = t.querySelector(sel);
      if (!b) return;
      b.addEventListener('pointerdown', function (e) { e.preventDefault(); e.stopPropagation(); fn(); }, { passive: false });
      b.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); });
    }
    tap('.mtb-knife', function () { toggleKnife(); });
    tap('.mtb-light', function () { startSwing(false); });
    tap('.mtb-heavy', function () { startSwing(true); });
    tap('.mtb-net', openLobby);
    tap('.mtb-board', toggleBoard);
  }
  function padIcon(kind) {
    if (kind === 'knife') return '<svg viewBox="0 0 48 48"><path d="M33 7l10 3-21 21-8 4-5 8 3-9 8-4z"/><path d="M13 31l4 4"/></svg>';
    if (kind === 'swing') return '<svg viewBox="0 0 48 48"><path d="M9 39L36 9"/><path d="M12 20c9 7 18 7 27 3"/></svg>';
    if (kind === 'mp') return '<svg viewBox="0 0 48 48"><path d="M18 30l-5 5a6 6 0 0 1-9-9l5-5"/><path d="M30 18l5-5a6 6 0 0 1 9 9l-5 5"/><path d="M19 29l10-10"/></svg>';
    return '<svg viewBox="0 0 48 48"><path d="M12 12h24"/><path d="M12 24h24"/><path d="M12 36h16"/></svg>';
  }
  var PTR = { ids: {}, seen: {}, fixAt: 0, lastPos: null, lastT: 0 };
  function ptrTrack() {
    if (PTR.on) return;
    PTR.on = true;
    window.addEventListener('pointerdown', function (e) {
      PTR.ids[e.pointerId] = performance.now();
      PTR.seen[e.pointerId] = performance.now();
    }, true);
    window.addEventListener('pointerup', function (e) { delete PTR.ids[e.pointerId]; }, true);
    window.addEventListener('pointercancel', function (e) { delete PTR.ids[e.pointerId]; }, true);
  }
  function releaseStuck() {
    var now = performance.now();
    if (now - PTR.fixAt < 1200) return;
    PTR.fixAt = now;
    for (var id in PTR.seen) {
      if (now - PTR.seen[id] > 4000) { delete PTR.seen[id]; continue; }
      try {
        window.dispatchEvent(new PointerEvent('pointerup', { pointerId: Number(id), bubbles: true, cancelable: true }));
        window.dispatchEvent(new PointerEvent('pointercancel', { pointerId: Number(id), bubbles: true, cancelable: true }));
      } catch (e) { }
      delete PTR.ids[id];
    }
    var zone = document.querySelector('#touch-ui .tc-stick-zone');
    if (zone) { try { zone.dispatchEvent(new PointerEvent('pointerup', { pointerId: -1, bubbles: true })); } catch (e2) { } }
  }
  function guardStick() {
    if (!isTouch()) return;
    ptrTrack();
    var h = hook(); if (!h || !h.player || !h.player.pos) return;
    var now = performance.now();
    var p = h.player.pos;
    if (!PTR.lastPos) { PTR.lastPos = { x: p.x, z: p.z }; PTR.lastT = now; return; }
    if (now - PTR.lastT < 700) return;
    var moved = Math.hypot(p.x - PTR.lastPos.x, p.z - PTR.lastPos.z);
    PTR.lastPos = { x: p.x, z: p.z };
    PTR.lastT = now;
    var touchIds = 0;
    for (var k in PTR.ids) touchIds++;
    if (touchIds === 0 && moved > 0.9) releaseStuck();
  }
  function ensurePads() {
    var ui = document.getElementById('touch-ui');
    if (!ui) return false;
    if (!PADS.style) {
      var st = document.createElement('style');
      st.id = 'clang-pad-css';
      st.textContent = '#touch-ui .tc-knife{position:absolute;left:auto;right:74px;top:9px;bottom:auto;width:52px;height:38px;min-width:52px;padding:0 6px;z-index:4;font:700 13px/1 Impact,Microsoft YaHei,sans-serif;border:3px solid #0b0806;border-radius:8px;box-shadow:2px 2px 0 #0b0806}#touch-ui .tc-knife.on{background:#f2c14e}#touch-ui .tc-mp,#touch-ui .tc-board{--w:56px;--fs:14px}#touch-ui .tc-mp{--l:152px;--b:36px}#touch-ui .tc-board{--l:214px;--b:36px}#touch-ui .tc-fire.knife-mode{background:#f2c14e}';
      (document.head || document.documentElement).appendChild(st);
      PADS.style = st;
    }
    var kb = ui.querySelector('.tc-btn.tc-knife');
    if (!kb) {
      kb = document.createElement('button');
      kb.type = 'button';
      kb.className = 'tc-btn tc-gun tc-knife';
      kb.setAttribute('data-a', 'knife');
      kb.innerHTML = '刀';
      kb.addEventListener('pointerdown', function (e) { e.preventDefault(); e.stopPropagation(); toggleKnife(); }, { passive: false });
      kb.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); });
      ui.appendChild(kb);
    }
    var defs = [
      { a: 'mp', cls: 'tc-mp', label: '联机', bl: '52vw', bb: '8vh', fn: function () { openLobby(); } },
      { a: 'board', cls: 'tc-board', label: '战绩', bl: '61vw', bb: '8vh', fn: function () { toggleBoard(); } }
    ];
    for (var i = 0; i < defs.length; i++) {
      var d = defs[i];
      var b = ui.querySelector('.tc-btn[data-a="' + d.a + '"]');
      if (!b) {
        b = document.createElement('button');
        b.type = 'button';
        b.className = 'tc-btn ' + d.cls;
        b.setAttribute('data-a', d.a);
        b.innerHTML = padIcon(d.a) + '<span>' + d.label + '</span>';
        (function (fn) {
          b.addEventListener('pointerdown', function (e) { e.preventDefault(); e.stopPropagation(); b.classList.add('down'); fn(); }, { passive: false });
          b.addEventListener('pointerup', function () { b.classList.remove('down'); });
          b.addEventListener('pointercancel', function () { b.classList.remove('down'); });
          b.addEventListener('lostpointercapture', function () { b.classList.remove('down'); });
          b.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); });
        })(d.fn);
        ui.appendChild(b);
      }
      b.style.left = 'calc(' + d.bl + ' - var(--x, 0px) * var(--k, 1))';
      b.style.bottom = 'calc(' + d.bb + ' + var(--y, 0px) * var(--k, 1))';
      b.style.right = 'auto';
      if (!b.style.getPropertyValue('--x')) b.style.setProperty('--x', '0px');
      if (!b.style.getPropertyValue('--y')) b.style.setProperty('--y', '0px');
      if (!b.style.getPropertyValue('--s')) b.style.setProperty('--s', '1');
      if (!b.style.getPropertyValue('--a')) b.style.setProperty('--a', '0.75');
      PADS.btns[d.a] = b;
    }
    PADS.btns.knife = kb;
    var fb = ui.querySelector('.tc-fire');
    if (fb) {
      if (!fb.__orig) fb.__orig = fb.innerHTML;
      if (KNIFE.out) { if (!fb.__knife) { fb.innerHTML = padIcon('swing') + '<span>砍</span>'; fb.__knife = true; fb.classList.add('knife-mode'); } }
      else if (fb.__knife) { fb.innerHTML = fb.__orig; fb.__knife = false; fb.classList.remove('knife-mode'); }
    }
    PADS.ready = true;
    return true;
  }
  function syncTouch() {
    if (!isTouch()) { if (TOUCH.el) TOUCH.el.classList.remove('show'); return; }
    var pads = ensurePads();
    if (TOUCH.el) TOUCH.el.classList.toggle('show', !pads && !!(document.body && document.body.classList.contains('walking')));
    if (mpEls.chip) mpEls.chip.classList.toggle('touchnone', true);
    if (pads) {
      var k = PADS.btns.knife;
      if (k) { k.textContent = KNIFE.out ? '收刀' : '刀'; k.classList.toggle('on', KNIFE.out); }
    } else if (TOUCH.el) {
      TOUCH.el.classList.toggle('armed', KNIFE.out);
      var k2 = TOUCH.el.querySelector('.mtb-knife');
      if (k2) k2.textContent = KNIFE.out ? '收刀' : '刀';
    }
  }
  var TAB = { host: null };
  var TAB_ICON = '<svg class="ic" viewBox="0 0 32 32" aria-hidden="true"><path d="M21 3 28 5 13 21 9 25 4 27 6 21 10 19z" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round"/><path d="M10 19 13 22" stroke="currentColor" stroke-width="2.4"/></svg>';
  function buildMenuTab() {
    if (TAB.host) return;
    var host = document.createElement('div');
    host.id = 'clang-mod-tab';
    host.setAttribute('translate', 'no');
    host.setAttribute('lang', 'zh-CN');
    host.style.cssText = 'position:absolute;display:none;pointer-events:auto;z-index:6';
    var sr = host.attachShadow({ mode: 'open' });
    sr.innerHTML = '<style>' +
      '.mtab{position:relative;display:flex;align-items:center;gap:calc(var(--u,1vh) * 1.1);width:100%;height:100%;padding:0 calc(var(--u,1vh) * 2.2);background:none;border:0;color:var(--ink,#201810);font-family:inherit;text-align:left;cursor:pointer;transform:rotate(-1.2deg)}' +
      '.mtab:active{transform:rotate(-1.2deg) translateY(2px)}' +
      '.mtab .frame{position:absolute;inset:0;z-index:-1;background:radial-gradient(#1c171217 1px,transparent 1.4px) 0 0/5px 5px,var(--paper,#f1e5c5);border:calc(var(--u,1vh) * .3) solid var(--ink,#201810);box-shadow:calc(var(--u,1vh)*.45) calc(var(--u,1vh)*.45) 0 var(--ink,#201810),calc(var(--u,1vh)*.8) calc(var(--u,1vh)*.8) 0 var(--teal,#3b6f6a)}' +
      '.mtab .ic{width:calc(var(--u,1vh)*2.4);height:calc(var(--u,1vh)*2.4);flex:none;color:var(--ink,#201810)}' +
      '.mtab span{font-size:calc(var(--u,1vh)*2.1);line-height:1;white-space:nowrap}' +
      '.mtab small{font-size:calc(var(--u,1vh)*1.3);opacity:.55;margin-left:.15em;white-space:nowrap}' +
      '</style>' +
      '<button class="mtab" type="button"><i class="frame"></i>' + TAB_ICON + '<span>哐当 MOD</span><small>刀 · 联机</small></button>';
    (document.body || document.documentElement).appendChild(host);
    TAB.host = host;
    var btn = sr.querySelector('.mtab');
    btn.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); openLobby(); });
  }
  function syncMenuTab() {
    var menu = document.querySelector('.sm-menu');
    if (!menu) return;
    if (!TAB.host) buildMenuTab();
    if (!TAB.host) return;
    if (TAB.host.parentNode !== menu) menu.appendChild(TAB.host);
    var set = menu.querySelector('[data-panel="settings"]');
    if (!set) { TAB.host.style.display = 'none'; return; }
    var r = set.getBoundingClientRect(), mr = menu.getBoundingClientRect();
    if (r.width < 10 || r.height < 4) { TAB.host.style.display = 'none'; return; }
    TAB.host.style.display = 'block';
    var gap = r.height * 0.18;
    var left = r.left - mr.left;
    var top = r.bottom - mr.top + gap;
    if (r.bottom + gap + r.height > (window.innerHeight || 800) - 4 && (r.bottom + gap + r.height - (window.innerHeight || 800)) > r.height * 0.4) {
      left = r.right - mr.left + r.width * 0.12;
      top = r.top - mr.top;
    }
    TAB.host.style.left = left + 'px';
    TAB.host.style.top = top + 'px';
    TAB.host.style.width = r.width + 'px';
    TAB.host.style.height = r.height + 'px';
  }
  function hudChip() {
    syncTouch();
    if (!mpEls.chip) return;
    mpEls.chip.classList.toggle('knife', KNIFE.out);
  }
  function namesForSelf() { return NET.name || '你'; }
  function mpHud() {
    if (!mpEls.armor) return;
    var on = NET.on;
    mpEls.armor.parentElement.style.display = on ? 'block' : 'none';
    mpEls.armor.style.width = clamp(NET.self.armor, 0, 100) + '%';
    mpEls.armor.style.background = NET.self.armor > 50 ? '#8fce4f' : NET.self.armor > 22 ? '#f5b82a' : '#ff5a3c';
    mpEls.score.textContent = NET.self.kills + ' / ' + NET.self.deaths;
    mpEls.ping.textContent = (NET.ping || 0) + ' ms';
    if (mpEls.go) mpEls.go.textContent = on ? '进入游戏' : '加入房间';
    if (mpEls.state) {
      mpEls.state.textContent = on ? ('已连接 · ' + (NET.room || '') + ' · ' + (NET.players.size + 1) + ' 人 · 中继 ' + NET.url) : (NET.msg || '未连接');
      mpEls.state.className = 'modmp-state' + (on ? ' on' : '');
    }
    var now2 = performance.now();
    if (now2 - (mpHud.t || 0) < 260) return;
    mpHud.t = now2;
    if (mpEls.list) {
      var rows = '<div class="modmp-row me"><b>' + esc(namesForSelf()) + '</b><span>' + NET.self.kills + ' 击杀 · ' + NET.self.deaths + ' 阵亡</span></div>';
      NET.players.forEach(function (r) {
        rows += '<div class="modmp-row"><b>' + esc(r.name) + '</b><span>' + (r.kills || 0) + ' 击杀 · ' + (performance.now() - r.last < 3200 ? '在线' : '离线') + '</span></div>';
      });
      mpEls.list.innerHTML = NET.on ? rows : '';
    }
    if (mpEls.board && !mpEls.board.hidden) renderBoard();
    mpEls.root.classList.toggle('online', on);
  }
  function renderBoard() {
    var rows = '<div class="modboard-row head"><span>呼号</span><span>击杀</span><span>阵亡</span><span>延迟</span></div>';
    rows += '<div class="modboard-row me"><span>' + esc(namesForSelf()) + '</span><span>' + NET.self.kills + '</span><span>' + NET.self.deaths + '</span><span>' + (NET.ping || 0) + '</span></div>';
    var all = [];
    NET.players.forEach(function (r) { all.push(r); });
    all.sort(function (a, b) { return (b.kills || 0) - (a.kills || 0); });
    all.forEach(function (r) {
      rows += '<div class="modboard-row"><span>' + esc(r.name) + '</span><span>' + (r.kills || 0) + '</span><span>' + (r.deaths || 0) + '</span><span>' + (r.ping || '--') + '</span></div>';
    });
    mpEls.board.querySelector('.modboard-rows').innerHTML = rows;
  }

  function downs() { }
  function ups() { }

  var held = false;
  function bindInput() {
    window.addEventListener('keydown', function (e) {
      var tg = (e.composedPath && e.composedPath()[0]) || e.target; if (tg && (tg.tagName === 'INPUT' || tg.tagName === 'TEXTAREA')) return;
      if (e.code === 'Escape' && mpEls.lobby && !mpEls.lobby.hidden) {
        mpEls.lobby.hidden = true;
        e.preventDefault();
        e.stopImmediatePropagation();
        return;
      }
      if (KBIND && !e.repeat) {
        KBIND = false;
        KKEY.code = e.code || 'KeyX';
        KKEY.label = keyLabel(KKEY.code);
        try { localStorage.setItem('clangKnifeKey', KKEY.code); } catch (er) { }
        updateKBind();
        e.preventDefault();
        e.stopImmediatePropagation();
        return;
      }
      if (e.code === KKEY.code && !e.repeat) { toggleKnife(); e.preventDefault(); }
      if (e.code === 'KeyP' && !e.repeat) {
        if (mpEls.lobby) { mpEls.lobby.hidden = !mpEls.lobby.hidden; if (!mpEls.lobby.hidden) mpHud(); }
        e.preventDefault();
      }
      if (e.code === 'KeyB' && NET.on && !e.repeat && mpEls.board) {
        mpEls.board.hidden = !mpEls.board.hidden;
        if (!mpEls.board.hidden) renderBoard();
        e.preventDefault();
      }
      if (e.code === 'Tab') {
        if (NET.on) {
          if (mpEls.board) { mpEls.board.hidden = false; renderBoard(); }
          e.preventDefault();
        }
      }
    }, true);
    window.addEventListener('keyup', function (e) {
      if (e.code === 'Tab' && NET.on && mpEls.board) { mpEls.board.hidden = true; e.preventDefault(); }
    }, true);
    function modUI(e) {
      var p = (e.composedPath && e.composedPath()) || [];
      for (var i = 0; i < p.length; i++) {
        var el = p[i];
        if (el && el.classList && (el.classList.contains('modtouch') || el.classList.contains('modhud') || el.classList.contains('modmp'))) return el;
      }
      return null;
    }
    function block(e) {
      var ui = modUI(e);
      if (ui && ui.classList.contains('modtouch')) return false;
      if (isTouch()) return false;
      if (!KNIFE.out) return false;
      if (hook() && hook().state && hook().state.locked === false) { toggleKnife(false); return false; }
      if (ui) return false;
      e.stopImmediatePropagation();
      e.preventDefault();
      return true;
    }
    window.addEventListener('pointerdown', function (e) {
      if (KNIFE.out) {
        var el0 = (e.composedPath && e.composedPath()[0]) || e.target;
        var fb0 = el0 && el0.closest ? el0.closest('.tc-fire') : null;
        if (fb0) { e.stopImmediatePropagation(); e.preventDefault(); swingCombo(); return; }
      }
      if (!block(e)) return;
      if (e.button === 0) startSwing(false);
      else if (e.button === 2) startSwing(true);
    }, true);
    window.addEventListener('mousedown', function (e) { block(e); }, true);
    window.addEventListener('contextmenu', function (e) { if (KNIFE.out) { e.preventDefault(); e.stopPropagation(); } }, true);
  }

  var last = 0;
  function tick(ts) {
    requestAnimationFrame(tick);
    var dt = last ? Math.min(0.05, (ts - last) / 1000) : 0.016;
    last = ts;

    if (!H) {
      if (!hook()) { bootTries++; return; }
      initOnce();
    }
    if (!SCENE) findScene();
    if (SCENE && !KNIFE.group) buildKnife();

    if (shakeUntil > ts) {
      var canv = document.querySelector('canvas');
      if (canv) {
        canv.style.transform = 'translate(' + (Math.random() * 2 - 1) * 3 + 'px,' + (Math.random() * 2 - 1) * 3 + 'px)';
      }
    } else {
      var c2 = document.querySelector('canvas');
      if (c2 && c2.style.transform) c2.style.transform = '';
    }

    patchRender();
    if (KNIFE.out) {
      if (hook() && hook().state && hook().state.locked === false) toggleKnife(false);
      else setGunVisible(false);
    }

    if (KNIFE.swingT >= 0) {
      KNIFE.swingT += dt;
      var t = clamp(KNIFE.swingT / KNIFE.swingDur, 0, 1);
      knifePose(t);
      if (!KNIFE.hitDone && t >= (KNIFE.heavy ? 0.4 : 0.42)) { KNIFE.hitDone = true; meleeStrike(); }
      if (t >= 1) { KNIFE.swingT = -1; knifePose(-1); }
    } else {
      knifePose(-1);
    }
    KNIFE.cool = Math.max(0, KNIFE.cool - dt);
    if (mpHitStopT > 0) mpHitStopT -= dt;

    stepFx(dt);
    for (var i = traces.length - 1; i >= 0; i--) {
      var tr = traces[i];
      tr.age += dt;
      tr.obj.material.opacity = Math.max(0, 0.85 - tr.age / 0.12);
      if (tr.age > 0.12) { if (tr.obj.parent) tr.obj.parent.remove(tr.obj); tr.obj.geometry.dispose(); tr.obj.material.dispose(); traces.splice(i, 1); }
    }
    stepNet(dt);
    if ((tick.n = (tick.n || 0) + 1) % 12 === 0) { syncMenuTab(); syncTouch(); ensureSceneReady(); guardStick(); if (mpEls.lobby && !mpEls.lobby.hidden) mpHud(); }
  }

  var inited = false;
  function initOnce() {
    if (inited) return;
    inited = true;
    buildHud();
    bindInput();
    initFx();
  }
  function ready() {
    requestAnimationFrame(tick);
    if (!hook()) {
      var t = setInterval(function () {
        if (hook()) {
          clearInterval(t);
          initOnce();
          try {
            var u = localStorage.getItem('clang.mp.url');
            if (u && localStorage.getItem('clang.mp.auto') === '1') netConnect(u, localStorage.getItem('clang.mp.room') || 'CLANG', localStorage.getItem('clang.mp.name') || '拆机工');
          } catch (e) { }
        }
      }, 250);
    }
  }
  if (document.readyState === 'complete' || document.readyState === 'interactive') setTimeout(ready, 60);
  else window.addEventListener('DOMContentLoaded', function () { setTimeout(ready, 60); });

  window.CLANG_MOD = {
    enemies: enemySnapshot,
    version: V,
    knife: toggleKnife,
    swing: startSwing,
    connect: netConnect,
    disconnect: netDisconnect,
    preview: function (which) {
      buildKnife();
      var h = hook(); if (!h || !KNIFE.group) return false;
      var target = which === 'walk' ? h.cameraWalk : (h.cameraOverview || h.camera);
      if (!target) return false;
      target.add(KNIFE.group);
      KNIFE.group.visible = true;
      KNIFE.pivot.rotation.set(-0.16, -0.42, 0.28);
      KNIFE.group.position.set(0.245, -0.235, -0.5);
      return true;
    },
    net: NET,
    hook: hook,
    state: function () {
      return {
        knifeOut: KNIFE.out, swings: KNIFE.swings || 0, hits: KNIFE.hits || 0, combo: KNIFE.comboN || 0, lastHeavy: !!KNIFE.heavy,
        net: { on: NET.on, id: NET.id, room: NET.room, players: NET.players.size, ping: NET.ping, armor: Math.round(NET.self.armor), kills: NET.self.kills, deaths: NET.self.deaths, down: NET.self.down, host: NET.host, isHost: isHost(), enSent: NET.enSent || 0, enApplied: NET.enApplied || 0 },
        scene: !!SCENE, cam: !!CAM
      };
    }
  };
})();
