(function () {
  function knife(T) {
    var g = new T.Group();
    g.renderOrder = 999;
    var pivot = new T.Group();
    g.add(pivot);

    var line = new T.MeshBasicMaterial({ color: 0x0b0907, depthTest: false, depthWrite: false, fog: false, side: T.BackSide });
    var steel = new T.MeshBasicMaterial({ color: 0x39414d, depthTest: false, depthWrite: false, fog: false });
    var face = new T.MeshBasicMaterial({ color: 0x5b6675, depthTest: false, depthWrite: false, fog: false });
    var edge = new T.MeshBasicMaterial({ color: 0xe4ecf7, depthTest: false, depthWrite: false, fog: false });
    var yellow = new T.MeshBasicMaterial({ color: 0xf5b82a, depthTest: false, depthWrite: false, fog: false });
    var grip = new T.MeshBasicMaterial({ color: 0x2b211a, depthTest: false, depthWrite: false, fog: false });
    var bolt = new T.MeshBasicMaterial({ color: 0x14181d, depthTest: false, depthWrite: false, fog: false });

    function add(geo, mat, x, y, z, rz, ol) {
      var m = new T.Mesh(geo, mat);
      m.position.set(x, y, z);
      if (rz) m.rotation.z = rz;
      m.frustumCulled = false;
      m.renderOrder = 1000;
      if (ol !== false) {
        var o = new T.Mesh(geo, line);
        o.position.copy(m.position);
        o.rotation.copy(m.rotation);
        o.scale.set(1.07, 1.07, 1.12);
        o.frustumCulled = false;
        o.renderOrder = 999;
        pivot.add(o);
      }
      pivot.add(m);
      return m;
    }

    add(new T.BoxGeometry(0.118, 0.41, 0.021), steel, 0, 0.305, 0);
    add(new T.BoxGeometry(0.084, 0.335, 0.008), face, 0.006, 0.295, 0.013);
    add(new T.BoxGeometry(0.019, 0.40, 0.027), edge, 0.059, 0.305, 0);
    add(new T.BoxGeometry(0.118, 0.016, 0.026), steel, 0, 0.515, 0);
    add(new T.BoxGeometry(0.082, 0.082, 0.021), steel, 0.036, 0.545, 0, 0.62);
    var bg = new T.CylinderGeometry(0.009, 0.009, 0.01, 6);
    bg.rotateX(Math.PI / 2);
    add(bg, bolt, 0.012, 0.395, 0.019, 0, false);
    add(bg, bolt, 0.012, 0.275, 0.019, 0, false);
    add(bg, bolt, 0.012, 0.155, 0.019, 0, false);
    add(new T.BoxGeometry(0.142, 0.03, 0.078), yellow, 0, 0.078, 0);
    add(new T.BoxGeometry(0.052, 0.205, 0.06), grip, 0, -0.048, 0);
    add(new T.BoxGeometry(0.056, 0.022, 0.064), yellow, 0, -0.062, 0, 0, false);
    add(new T.BoxGeometry(0.056, 0.018, 0.064), grip, 0, -0.108, 0, 0, false);
    add(new T.BoxGeometry(0.064, 0.026, 0.066), steel, 0, -0.158, 0);

    pivot.rotation.set(-1.25, 0.05, -0.32);
    pivot.position.set(0, -0.02, 0);
    g.position.set(0.38, -0.34, -0.47);
    g.scale.setScalar(0.52);
    g.visible = false;
    return { group: g, pivot: pivot, materials: { steel: steel, face: face, edge: edge, yellow: yellow, grip: grip } };
  }

  function nameSprite(T, name, color) {
    var c = document.createElement('canvas');
    c.width = 256; c.height = 64;
    var x = c.getContext('2d');
    x.fillStyle = 'rgba(20,16,12,.82)';
    x.fillRect(0, 0, 256, 64);
    x.fillStyle = '#' + ('000000' + color.toString(16)).slice(-6);
    x.fillRect(0, 0, 8, 64);
    x.font = 'bold 30px Bahnschrift, "Microsoft YaHei", sans-serif';
    x.fillStyle = '#efe4cc';
    x.textBaseline = 'middle';
    x.fillText(String(name).slice(0, 8), 18, 34);
    var tex = new T.CanvasTexture(c);
    if (T.SRGBColorSpace) tex.colorSpace = T.SRGBColorSpace;
    var sp = new T.Sprite(new T.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, fog: false }));
    sp.scale.set(1.9, 0.475, 1);
    sp.renderOrder = 50;
    return sp;
  }

  function avatar(T, name, idx, id) {
    var cols = [0xf5b82a, 0x4fb3d9, 0xd9534f, 0x8fce4f, 0xc56bdd, 0xe08a3c];
    var col = cols[(idx || 0) % cols.length];
    var g = new T.Group();
    var body = new T.MeshStandardMaterial({ color: col, metalness: 0.32, roughness: 0.6, fog: true });
    var dark = new T.MeshStandardMaterial({ color: 0x2b231d, metalness: 0.55, roughness: 0.55, fog: true });
    var steel = new T.MeshStandardMaterial({ color: 0x6d6659, metalness: 0.8, roughness: 0.45, fog: true });
    var visor = new T.MeshBasicMaterial({ color: 0xfff2cc, fog: false });

    var ink = new T.MeshBasicMaterial({ color: 0x0b0907, side: T.BackSide, fog: true });
    function part(geo, mat, x, y, z, ol) {
      var m = new T.Mesh(geo, mat);
      m.position.set(x, y, z);
      m.castShadow = true;
      if (ol !== false) {
        var o = new T.Mesh(geo, ink);
        o.position.set(x, y, z);
        o.scale.set(1.06, 1.06, 1.06);
        g.add(o);
      }
      g.add(m);
      return m;
    }

    part(new T.BoxGeometry(0.52, 0.54, 0.30), body, 0, 1.22, 0);
    part(new T.BoxGeometry(0.36, 0.20, 0.26), dark, 0, 0.92, 0, false);
    part(new T.BoxGeometry(0.20, 0.16, 0.24), body, -0.33, 1.44, 0);
    part(new T.BoxGeometry(0.20, 0.16, 0.24), body, 0.33, 1.44, 0);
    part(new T.BoxGeometry(0.30, 0.12, 0.30), steel, 0, 1.52, 0);
    var head = part(new T.BoxGeometry(0.24, 0.24, 0.24), dark, 0, 1.65, 0);
    part(new T.SphereGeometry(0.155, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.62), steel, 0, 1.68, 0);
    part(new T.BoxGeometry(0.245, 0.055, 0.02), visor, 0, 1.65, 0.125);
    part(new T.BoxGeometry(0.06, 0.06, 0.05), visor, 0, 1.65, -0.125);

    var armL = part(new T.BoxGeometry(0.12, 0.50, 0.13), dark, -0.34, 1.18, 0);
    var armR = part(new T.BoxGeometry(0.12, 0.50, 0.13), dark, 0.34, 1.18, 0);
    var legL = part(new T.BoxGeometry(0.17, 0.80, 0.20), dark, -0.14, 0.44, 0);
    var legR = part(new T.BoxGeometry(0.17, 0.80, 0.20), dark, 0.14, 0.44, 0);
    part(new T.BoxGeometry(0.19, 0.12, 0.28), steel, -0.14, 0.06, 0.04, false);
    part(new T.BoxGeometry(0.19, 0.12, 0.28), steel, 0.14, 0.06, 0.04, false);

    var gun = new T.Mesh(new T.BoxGeometry(0.085, 0.10, 0.42), dark);
    gun.position.set(0.30, 1.20, -0.36);
    g.add(gun);
    var pack = part(new T.BoxGeometry(0.32, 0.36, 0.13), steel, 0, 1.22, 0.20);

    var plate = nameSprite(T, name, col);
    plate.position.set(0, 2.14, 0);
    plate.scale.set(1.16, 0.29, 1);
    g.add(plate);

    g.userData = {
      id: id, name: name, idx: idx, legL: legL, legR: legR, armL: armL, armR: armR,
      head: head, plate: plate, gun: gun, color: col,
      target: new T.Vector3(), cur: new T.Vector3(), yawCur: 0, tYaw: 0, speed: 0, knife: false, flash: 0
    };
    g.position.set(0, -50, 0);
    return g;
  }

  window.CLANG_PARTS = { knife: knife, avatar: avatar, nameSprite: nameSprite };
})();
