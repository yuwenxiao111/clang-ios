#!/bin/bash
set -e
cd "$(dirname "$0")"
command -v xcodegen >/dev/null 2>&1 || { echo "缺少 xcodegen，先执行 brew install xcodegen"; exit 1; }
xcodegen generate
rm -rf build
xcodebuild -project CLANG.xcodeproj -scheme CLANG -configuration Release -sdk iphoneos \
  -archivePath build/CLANG.xcarchive archive CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO
mkdir -p build/ipa/Payload
cp -R build/CLANG.xcarchive/Products/Applications/CLANG.app build/ipa/Payload/
cd build/ipa
zip -qry ../CLANG-unsigned.ipa Payload
echo "完成：$(pwd)/../CLANG-unsigned.ipa"
