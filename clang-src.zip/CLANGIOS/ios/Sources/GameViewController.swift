import UIKit
import WebKit

final class GameViewController: UIViewController, WKNavigationDelegate {

    private var webView: WKWebView!

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.043, green: 0.031, blue: 0.024, alpha: 1)

        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.suppressesIncrementalRendering = false
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        config.preferences.setValue(true, forKey: "allowFileAccessFromFileURLs")
        config.preferences.setValue(true, forKey: "allowUniversalAccessFromFileURLs")

        config.preferences.javaScriptEnabled = true

        let unlock = """
        (function () {
          var instances = [];
          function track(ctx) {
            if (!ctx) return;
            instances.push(ctx);
            try {
              if (ctx.addEventListener) {
                ctx.addEventListener('statechange', function () {
                  if (ctx.state === 'suspended') { try { ctx.resume(); } catch (e) {} }
                });
              }
            } catch (e) {}
          }
          var AC = window.AudioContext || window.webkitAudioContext;
          if (AC) {
            function Patched() {
              var ctx = new AC();
              track(ctx);
              try { if (ctx.state === 'suspended') ctx.resume(); } catch (e) {}
              return ctx;
            }
            Patched.prototype = AC.prototype;
            window.AudioContext = Patched;
            window.webkitAudioContext = Patched;
          }
          function unlock() {
            for (var i = 0; i < instances.length; i++) {
              var c = instances[i];
              try { if (c.state === 'suspended') c.resume(); } catch (e) {}
            }
          }
          window.__unlockAudio = unlock;
          var evs = ['touchstart', 'touchend', 'pointerdown', 'pointerup', 'mousedown', 'mouseup', 'click', 'keydown'];
          evs.forEach(function (ev) {
            window.addEventListener(ev, unlock, { capture: true, passive: true });
          });
          var booted = false;
          function boot() {
            if (booted) return; booted = true;
            try {
              var a = document.createElement('audio');
              a.preload = 'auto'; a.loop = true; a.muted = true;
              a.setAttribute('x-webkit-airplay', 'deny');
              var p = a.play();
              if (p && p.catch) p.catch(function () {});
            } catch (e) {}
          }
          ['touchstart', 'pointerdown', 'mousedown', 'click'].forEach(function (ev) {
            window.addEventListener(ev, boot, { capture: true, passive: true });
          });
        })();
        """
        config.userContentController.addUserScript(WKUserScript(source: unlock, injectionTime: .atDocumentStart, forMainFrameOnly: false))

        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.scrollView.bounces = false
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.allowsBackForwardNavigationGestures = false
        if #available(iOS 16.4, *) { webView.isInspectable = true }
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        loadGame()
    }

    private func loadGame() {
        guard let root = Bundle.main.resourceURL?.appendingPathComponent("web"),
              let index = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "web") else {
            showMissing()
            return
        }
        webView.loadFileURL(index, allowingReadAccessTo: root)
    }

    private func showMissing() {
        let label = UILabel()
        label.text = "缺少内置网页资源 web/index.html"
        label.textColor = .white
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            label.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        print("web load failed: \(error)")
    }
}
