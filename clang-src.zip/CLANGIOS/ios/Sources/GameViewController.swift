import UIKit
import WebKit

final class GameViewController: UIViewController, WKNavigationDelegate {

    private var webView: WKWebView!

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.043, green: 0.031, blue: 0.024, alpha: 1)

        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.suppressesIncrementalRendering = false
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        config.preferences.setValue(true, forKey: "allowFileAccessFromFileURLs")
        config.preferences.setValue(true, forKey: "allowUniversalAccessFromFileURLs")

        let unlock = """
        (function () {
          var AC = window.AudioContext || window.webkitAudioContext;
          if (!AC) return;
          var orig = AC;
          function Patched() {
            var ctx = new orig();
            try { if (ctx.state === 'suspended') ctx.resume(); } catch (e) {}
            var r = ctx.resume.bind(ctx);
            ctx.resume = function () { var p = r(); try { p && p.catch && p.catch(function(){}); } catch (e) {} return p; };
            window.__clangCtx = ctx;
            return ctx;
          }
          Patched.prototype = orig.prototype;
          window.AudioContext = Patched;
          window.webkitAudioContext = Patched;
          function kick() {
            try { if (window.__clangCtx && window.__clangCtx.state === 'suspended') window.__clangCtx.resume(); } catch (e) {}
          }
          ['touchstart', 'touchend', 'pointerdown', 'click', 'keydown'].forEach(function (ev) {
            window.addEventListener(ev, kick, { capture: true, passive: true });
          });
        })();
        """
        config.userContentController.addUserScript(WKUserScript(source: unlock, injectionTime: .atDocumentStart, forMainFrameOnly: true))

        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.scrollView.bounces = false
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.allowsBackForwardNavigationGestures = false
        if #available(iOS 16.4, *) { webView.isInspectable = true }
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        loadGame()
    }

    private func loadGame() {
        guard let root = Bundle.main.resourceURL?.appendingPathComponent("web"),
              let index = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "web") else {
            showMissing()
            return
        }
        webView.loadFileURL(index, allowingReadAccessTo: root)
    }

    private func showMissing() {
        let label = UILabel()
        label.text = "缺少内置网页资源 web/index.html"
        label.textColor = .white
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            label.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        print("web load failed: \(error)")
    }
}
